import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import JSZip from "jszip";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // API Route: Health check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      hasGeminiKey: !!process.env.GEMINI_API_KEY,
    });
  });

  // API Route: Generate Character Backstory using Gemini
  app.post("/api/generate-backstory", async (req, res) => {
    try {
      const { name, characterClass, stats } = req.body;
      if (!name || !characterClass) {
        return res.status(400).json({ error: "Name and characterClass are required." });
      }

      const ai = getGeminiClient();
      if (!ai) {
        return res.status(200).json({
          backstory: null,
          message: "No GEMINI_API_KEY configured. Fallback generator active.",
        });
      }

      const prompt = `You are a legendary fantasy chronicler. Write an evocative, unique, and punchy 1-to-2-sentence origin story for a fantasy character named "${name}", who is a ${characterClass} with ${stats?.health || 100} Health, ${stats?.mana || 100} Mana, and ${stats?.strength || 100} Strength. Return ONLY the 1 to 2 sentences. Do not use quotes or introductory text.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          temperature: 1.0,
          systemInstruction: "You write brief, vivid 1-2 sentence fantasy origin lore.",
        },
      });

      const backstory = response.text?.trim() || null;
      return res.json({ backstory });
    } catch (error: any) {
      console.error("Backstory generation error:", error);
      return res.status(200).json({
        backstory: null,
        error: error.message || "Failed to generate backstory with Gemini.",
      });
    }
  });

  // API Route: Generate Character Portrait using Gemini
  app.post("/api/generate-portrait", async (req, res) => {
    try {
      const { name, characterClass, style = "cartoon video game" } = req.body;
      if (!name || !characterClass) {
        return res.status(400).json({ error: "Name and characterClass are required." });
      }

      const ai = getGeminiClient();
      if (!ai) {
        return res.status(200).json({
          imageUrl: null,
          fallback: true,
          message: "GEMINI_API_KEY not configured. Falling back to vector stylized avatar.",
        });
      }

      const imagePrompt = `A high quality, vibrant cartoon video game style square portrait bust of a fantasy character named ${name}, a ${characterClass}. Colorful cel-shaded RPG art, clear expressive face, iconic fantasy armor or wizard robes, dramatic magical rim lighting, fantasy game character card art.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite-image",
        contents: {
          parts: [{ text: imagePrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          },
        },
      });

      let imageUrl: string | null = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      return res.json({
        imageUrl,
        fallback: !imageUrl,
      });
    } catch (error: any) {
      console.error("Portrait generation error:", error);
      return res.status(200).json({
        imageUrl: null,
        fallback: true,
        error: error.message || "Failed to generate AI portrait.",
      });
    }
  });

  // API Route: Download project source code as a ZIP file (Task 6)
  app.get("/api/download-zip", async (_req, res) => {
    try {
      const zip = new JSZip();
      const rootDir = process.cwd();

      // Collect key application files to include in the ZIP
      const filesToInclude = [
        "package.json",
        "index.html",
        "metadata.json",
        "tsconfig.json",
        "vite.config.ts",
        ".env.example",
        "server.ts",
        "src/App.tsx",
        "src/main.tsx",
        "src/index.css",
        "src/types.ts",
        "src/utils/characterGenerator.ts",
        "src/utils/zipExporter.ts",
        "src/components/PlayerCard.tsx",
        "src/components/MyDeckModal.tsx",
        "src/components/WorkbenchDecorations.tsx",
      ];

      for (const relPath of filesToInclude) {
        const fullPath = path.join(rootDir, relPath);
        if (fs.existsSync(fullPath)) {
          const content = fs.readFileSync(fullPath, "utf-8");
          zip.file(relPath, content);
        }
      }

      // Add a README.md for the downloaded archive
      zip.file(
        "README.md",
        `# Fantasy Character Generator

An ancient alchemist's workbench fantasy character creator featuring:
- Core random fantasy character generation (Name, Title, Class)
- Player Card UI with glowing ornate borders
- Health, Mana, and Strength randomized stats
- Cartoon / Video Game style character portraits with Generate & Regenerate buttons
- 1-to-2 sentence unique character origin backstories
- "Save to Deck" local persistence for managing your custom card deck
- Full-stack Express + Vite + Gemini AI architecture

## Quickstart
1. Run \`npm install\`
2. Set your \`GEMINI_API_KEY\` in \`.env\`
3. Run \`npm run dev\`
4. Open http://localhost:3000
`
      );

      const zipBuffer = await zip.generateAsync({ type: "nodebuffer" });
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="Fantasy-Character-Generator.zip"'
      );
      res.send(zipBuffer);
    } catch (err: any) {
      console.error("ZIP packaging error:", err);
      res.status(500).json({ error: "Failed to generate project ZIP." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Fantasy Character Generator server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
