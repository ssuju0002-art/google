import React from 'react';
import { 
  X, 
  Trash2, 
  ArrowUpRight, 
  Layers, 
  Heart, 
  Sparkles, 
  Sword, 
  Download,
  Scroll
} from 'lucide-react';
import { Character, DeckItem } from '../types';
import { CLASS_THEMES } from '../utils/characterGenerator';

interface MyDeckModalProps {
  isOpen: boolean;
  onClose: () => void;
  deck: DeckItem[];
  onSelectCharacter: (char: Character) => void;
  onRemoveFromDeck: (id: string) => void;
  onClearDeck: () => void;
}

export const MyDeckModal: React.FC<MyDeckModalProps> = ({
  isOpen,
  onClose,
  deck,
  onSelectCharacter,
  onRemoveFromDeck,
  onClearDeck,
}) => {
  if (!isOpen) return null;

  return (
    <div 
      id="my-deck-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-2xl max-h-[85vh] bg-[#14100d] border-2 border-amber-600/50 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-amber-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-amber-900/50 bg-[#191410]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-950/80 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-fantasy text-xl text-amber-200 tracking-wide">
                My Deck
              </h3>
              <p className="text-xs text-amber-500/80 font-cinzel">
                {deck.length} {deck.length === 1 ? 'Champion' : 'Champions'} in Vault
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {deck.length > 0 && (
              <button
                id="btn-clear-deck"
                type="button"
                onClick={() => {
                  if (window.confirm('Remove all characters from your deck?')) {
                    onClearDeck();
                  }
                }}
                className="px-2.5 py-1 text-xs text-red-400 hover:text-red-300 font-cinzel hover:bg-red-950/40 rounded transition-colors cursor-pointer"
              >
                Clear All
              </button>
            )}
            <button
              id="btn-close-deck-modal"
              type="button"
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-amber-200 hover:bg-amber-950/60 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Deck List Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {deck.length === 0 ? (
            <div className="text-center py-16 px-4 flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-amber-950/40 border border-amber-600/30 flex items-center justify-center text-amber-500/60 mb-3">
                <Scroll className="w-8 h-8" />
              </div>
              <h4 className="font-fantasy text-lg text-amber-300 mb-1">
                Your Deck is Empty
              </h4>
              <p className="text-xs text-stone-400 max-w-sm font-cinzel leading-relaxed">
                Forge fantasy characters on the alchemist's workbench and click{' '}
                <span className="text-amber-400 font-bold">"Save to Deck"</span> to collect your favorites here!
              </p>
            </div>
          ) : (
            deck.map((char) => {
              const theme = CLASS_THEMES[char.class] || CLASS_THEMES.Warrior;
              return (
                <div
                  key={char.id}
                  id={`deck-item-${char.id}`}
                  className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-[#1c1612] border border-amber-900/40 hover:border-amber-600/60 transition-all group"
                >
                  {/* Left: Thumbnail & Core Info */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <img
                      src={char.portraitUrl}
                      alt={char.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-lg object-cover border border-amber-700/60 shrink-0 bg-stone-900"
                    />

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-fantasy text-base text-amber-200 truncate">
                          {char.name}
                        </span>
                        <span className={`px-2 py-0.5 text-[11px] rounded-full border font-cinzel font-semibold ${theme.badgeBg} ${theme.badgeText}`}>
                          {char.class}
                        </span>
                      </div>
                      
                      <p className="text-[11px] text-amber-500/80 font-cinzel italic truncate">
                        {char.title}
                      </p>

                      {/* Stats Pills */}
                      <div className="flex items-center gap-3 mt-1.5 text-[11px] font-mono">
                        <span className="flex items-center gap-1 text-red-400">
                          <Heart className="w-3 h-3 fill-red-500/20" />
                          <span>{char.stats.health}</span>
                        </span>
                        <span className="flex items-center gap-1 text-blue-400">
                          <Sparkles className="w-3 h-3" />
                          <span>{char.stats.mana}</span>
                        </span>
                        <span className="flex items-center gap-1 text-amber-400">
                          <Sword className="w-3 h-3" />
                          <span>{char.stats.strength}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        onSelectCharacter(char);
                        onClose();
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-cinzel font-bold text-amber-200 bg-amber-950/80 hover:bg-amber-900 border border-amber-600/50 rounded-lg transition-all active:scale-95 cursor-pointer"
                      title="Load this character onto the workbench"
                    >
                      <span>Load to Bench</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onRemoveFromDeck(char.id)}
                      className="p-1.5 text-stone-400 hover:text-red-400 hover:bg-red-950/40 border border-transparent hover:border-red-900/40 rounded-lg transition-colors cursor-pointer"
                      title="Remove from deck"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-amber-900/40 bg-[#191410] flex items-center justify-between text-xs text-stone-400 font-cinzel">
          <span>Saved locally on your device</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-700 text-amber-100 rounded-lg transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
