import React from 'react';

export const WorkbenchDecorations: React.FC = () => {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden select-none z-0">
      {/* Mystical Transmutation Circle Background behind the card */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] md:w-[850px] md:h-[850px] rounded-full border border-amber-600/15 animate-[spin_120s_linear_infinite] flex items-center justify-center">
        {/* Inner concentric circles */}
        <div className="w-5/6 h-5/6 rounded-full border border-dashed border-amber-500/20 flex items-center justify-center">
          <div className="w-4/6 h-4/6 rounded-full border border-amber-400/20 flex items-center justify-center">
            <div className="w-1/2 h-1/2 border border-amber-500/10 rotate-45" />
          </div>
        </div>
      </div>

      {/* Ambient glowing dust / embers */}
      <div className="absolute top-12 left-10 w-2 h-2 rounded-full bg-amber-400/40 blur-[1px] animate-pulse" />
      <div className="absolute top-1/4 right-16 w-3 h-3 rounded-full bg-emerald-400/30 blur-[2px] animate-pulse" />
      <div className="absolute bottom-20 left-1/4 w-2.5 h-2.5 rounded-full bg-purple-400/30 blur-[2px] animate-pulse" />
      <div className="absolute bottom-32 right-1/4 w-2 h-2 rounded-full bg-amber-300/40 blur-[1px] animate-pulse" />

      {/* Top Left Alchemical Rune Seal */}
      <div className="absolute top-4 left-6 hidden lg:flex items-center gap-3 opacity-30 text-amber-500 font-cinzel text-xs tracking-widest uppercase">
        <span className="text-base">⚗</span>
        <span>Athanor v4.2 • Prima Materia</span>
      </div>

      {/* Top Right Alchemical Rune Seal */}
      <div className="absolute top-4 right-6 hidden lg:flex items-center gap-3 opacity-30 text-amber-500 font-cinzel text-xs tracking-widest uppercase">
        <span>Transmutatio Magna</span>
        <span className="text-base">☉</span>
      </div>

      {/* Alchemist Flasks & Phials in bottom corners */}
      <div className="absolute -bottom-6 -left-6 hidden md:block opacity-25">
        <svg width="140" height="140" viewBox="0 0 100 100" fill="none">
          <path d="M 40,20 L 40,45 L 20,85 C 18,89 21,95 26,95 L 74,95 C 79,95 82,89 80,85 L 60,45 L 60,20 Z" stroke="#d97706" strokeWidth="2" fill="rgba(217, 119, 6, 0.08)" />
          <path d="M 28,75 Q 50,65 72,75 L 76,90 L 24,90 Z" fill="rgba(16, 185, 129, 0.25)" />
          <line x1="36" y1="20" x2="64" y2="20" stroke="#d97706" strokeWidth="3" />
        </svg>
      </div>

      <div className="absolute -bottom-6 -right-6 hidden md:block opacity-25">
        <svg width="140" height="140" viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="65" r="30" stroke="#f59e0b" strokeWidth="2" fill="rgba(147, 51, 234, 0.15)" />
          <rect x="44" y="15" width="12" height="25" stroke="#f59e0b" strokeWidth="2" fill="rgba(245, 158, 11, 0.05)" />
          <circle cx="50" cy="70" r="16" fill="rgba(236, 72, 153, 0.3)" />
        </svg>
      </div>
    </div>
  );
};
