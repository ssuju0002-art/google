import React, { useState } from 'react';
import { 
  Heart, 
  Sparkles, 
  Sword, 
  Bookmark, 
  BookmarkCheck, 
  RefreshCw, 
  Image as ImageIcon, 
  Scroll, 
  ShieldAlert, 
  Flame,
  Wand2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Character } from '../types';
import { CLASS_THEMES } from '../utils/characterGenerator';

interface PlayerCardProps {
  character: Character;
  isSaved: boolean;
  onSaveToDeck: () => void;
  onGeneratePortrait: () => Promise<void>;
  onRegeneratePortrait: () => Promise<void>;
  onGenerateBackstory: () => Promise<void>;
  isPortraitLoading?: boolean;
  isBackstoryLoading?: boolean;
}

export const PlayerCard: React.FC<PlayerCardProps> = ({
  character,
  isSaved,
  onSaveToDeck,
  onGeneratePortrait,
  onRegeneratePortrait,
  onGenerateBackstory,
  isPortraitLoading = false,
  isBackstoryLoading = false,
}) => {
  const theme = CLASS_THEMES[character.class] || CLASS_THEMES.Warrior;
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Maximum benchmark values for stat bars
  const maxStats = {
    health: 220,
    mana: 200,
    strength: 180,
  };

  const hpPercent = Math.min(100, Math.round((character.stats.health / maxStats.health) * 100));
  const manaPercent = Math.min(100, Math.round((character.stats.mana / maxStats.mana) * 100));
  const strPercent = Math.min(100, Math.round((character.stats.strength / maxStats.strength) * 100));

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case 'Legendary':
        return 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold border-amber-300';
      case 'Epic':
        return 'bg-gradient-to-r from-purple-700 to-fuchsia-600 text-purple-100 border-purple-400';
      case 'Rare':
        return 'bg-gradient-to-r from-blue-700 to-cyan-600 text-blue-100 border-blue-400';
      default:
        return 'bg-stone-800 text-stone-300 border-stone-600';
    }
  };

  return (
    <motion.div
      id="fantasy-player-card"
      initial={{ scale: 0.96, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="relative w-full max-w-[440px] mx-auto rounded-2xl p-[3px] bg-gradient-to-b from-amber-500/60 via-amber-800/40 to-stone-900 gold-border-card group select-none"
    >
      {/* Ornate Card Corner Ornaments */}
      <div className="absolute -top-2 -left-2 w-6 h-6 border-t-2 border-l-2 border-amber-400 z-20 pointer-events-none" />
      <div className="absolute -top-2 -right-2 w-6 h-6 border-t-2 border-r-2 border-amber-400 z-20 pointer-events-none" />
      <div className="absolute -bottom-2 -left-2 w-6 h-6 border-b-2 border-l-2 border-amber-400 z-20 pointer-events-none" />
      <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-2 border-r-2 border-amber-400 z-20 pointer-events-none" />

      {/* Main Card Interior */}
      <div className="relative rounded-[13px] bg-[#120f0d] text-amber-100 p-5 overflow-hidden flex flex-col gap-4 border border-amber-500/20">
        
        {/* Subtle Card Background Watermark Rune */}
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full border border-amber-500/10 pointer-events-none flex items-center justify-center opacity-40">
          <div className="w-32 h-32 border border-amber-500/10 rotate-12" />
        </div>

        {/* Card Header: Name, Title, and Class Badge */}
        <div className="flex items-start justify-between gap-3 border-b border-amber-900/40 pb-3">
          <div className="flex-1 min-w-0">
            {/* Task 3: Stylized fantasy-style font for character name */}
            <h2 
              id="character-card-name"
              className="font-fantasy text-2xl sm:text-3xl text-amber-200 tracking-wide leading-tight truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
              title={character.name}
            >
              {character.name}
            </h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs text-amber-400/80 font-cinzel italic truncate">
                {character.title}
              </span>
              <span className="text-[10px] text-amber-600">•</span>
              <span className="text-[11px] uppercase tracking-wider text-stone-400 font-cinzel font-semibold">
                {character.element}
              </span>
            </div>
          </div>

          {/* Class & Rarity Badges */}
          <div className="flex flex-col items-end gap-1.5 shrink-0">
            <span className={`px-2.5 py-0.5 text-xs rounded-full border font-cinzel font-bold shadow-sm ${theme.badgeBg} ${theme.badgeText}`}>
              {character.class}
            </span>
            <span className={`px-2 py-0.5 text-[10px] rounded border uppercase tracking-wider ${getRarityBadge(character.rarity)}`}>
              {character.rarity}
            </span>
          </div>
        </div>

        {/* Task 2: Character Portrait Area & Generate/Regenerate Controls */}
        <div className="relative w-full aspect-square max-h-[260px] rounded-xl overflow-hidden border-2 border-amber-700/50 bg-[#090706] shadow-inner group/portrait">
          {/* Portrait Image */}
          <img
            id="character-portrait-image"
            src={character.portraitUrl}
            alt={`${character.name} the ${character.class}`}
            referrerPolicy="no-referrer"
            className={`w-full h-full object-cover transition-all duration-300 ${
              isPortraitLoading ? 'scale-105 blur-sm brightness-75' : 'scale-100 blur-0'
            }`}
          />

          {/* Loading Overlay */}
          {isPortraitLoading && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center gap-2 text-amber-300">
              <RefreshCw className="w-8 h-8 animate-spin text-amber-400" />
              <span className="font-cinzel text-xs uppercase tracking-widest text-amber-200">
                Summoning Visage...
              </span>
            </div>
          )}

          {/* Portrait Style Pill */}
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md border border-amber-500/30 text-[10px] font-cinzel text-amber-300/90 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Cartoon RPG Portrait</span>
          </div>

          {/* Task 2: Generate and Regenerate Portrait Buttons */}
          <div className="absolute bottom-2 inset-x-2 flex items-center justify-between gap-2 p-1.5 rounded-lg bg-black/80 backdrop-blur-md border border-amber-700/40">
            <button
              id="btn-generate-portrait"
              type="button"
              onClick={onGeneratePortrait}
              disabled={isPortraitLoading}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-cinzel font-bold text-amber-200 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-600/40 rounded transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
              title="Generate a new cartoon/video game style portrait"
            >
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>Generate Portrait</span>
            </button>

            <button
              id="btn-regenerate-portrait"
              type="button"
              onClick={onRegeneratePortrait}
              disabled={isPortraitLoading}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-cinzel font-bold text-amber-200 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-600/40 rounded transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
              title="Regenerate portrait variation"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isPortraitLoading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Regenerate</span>
            </button>
          </div>
        </div>

        {/* Task 5: Stats Section (Health, Mana, Strength) */}
        <div id="character-stats-container" className="grid grid-cols-3 gap-2 bg-[#19130f]/80 p-2.5 rounded-xl border border-amber-900/40">
          {/* Health Stat */}
          <div className="flex flex-col gap-1 p-2 rounded-lg bg-stone-900/60 border border-red-900/30">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1 text-red-400 font-cinzel font-semibold">
                <Heart className="w-3.5 h-3.5 fill-red-500/20 text-red-500" />
                <span>Health</span>
              </span>
              <span className="font-mono font-bold text-red-200 text-xs">
                {character.stats.health}
              </span>
            </div>
            <div className="w-full bg-stone-950 h-1.5 rounded-full overflow-hidden border border-red-950">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${hpPercent}%` }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="h-full bg-gradient-to-r from-red-600 to-rose-400 rounded-full"
              />
            </div>
          </div>

          {/* Mana Stat */}
          <div className="flex flex-col gap-1 p-2 rounded-lg bg-stone-900/60 border border-blue-900/30">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1 text-blue-400 font-cinzel font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                <span>Mana</span>
              </span>
              <span className="font-mono font-bold text-blue-200 text-xs">
                {character.stats.mana}
              </span>
            </div>
            <div className="w-full bg-stone-950 h-1.5 rounded-full overflow-hidden border border-blue-900">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${manaPercent}%` }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="h-full bg-gradient-to-r from-blue-600 to-cyan-400 rounded-full"
              />
            </div>
          </div>

          {/* Strength Stat */}
          <div className="flex flex-col gap-1 p-2 rounded-lg bg-stone-900/60 border border-amber-900/30">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1 text-amber-400 font-cinzel font-semibold">
                <Sword className="w-3.5 h-3.5 text-amber-400" />
                <span>Strength</span>
              </span>
              <span className="font-mono font-bold text-amber-200 text-xs">
                {character.stats.strength}
              </span>
            </div>
            <div className="w-full bg-stone-950 h-1.5 rounded-full overflow-hidden border border-amber-950">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${strPercent}%` }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="h-full bg-gradient-to-r from-amber-600 to-yellow-400 rounded-full"
              />
            </div>
          </div>
        </div>

        {/* Task 4: Character Backstory Section with "Generate Backstory" button */}
        <div className="relative flex flex-col gap-2 p-3 rounded-xl bg-gradient-to-br from-[#1b1511] to-[#140f0c] border border-amber-800/30 shadow-inner">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-amber-400/90 font-cinzel font-bold uppercase tracking-wider">
              <Scroll className="w-3.5 h-3.5 text-amber-500" />
              <span>Origin Backstory</span>
            </div>

            {/* Task 4: "Generate Backstory" Button */}
            <button
              id="btn-generate-backstory"
              type="button"
              onClick={onGenerateBackstory}
              disabled={isBackstoryLoading}
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-cinzel font-semibold text-amber-200 bg-amber-950/70 hover:bg-amber-900 border border-amber-600/50 rounded transition-all active:scale-95 disabled:opacity-50 cursor-pointer shadow-xs"
              title="Generate a unique 1-to-2 sentence origin story"
            >
              <Wand2 className={`w-3 h-3 text-amber-400 ${isBackstoryLoading ? 'animate-spin' : ''}`} />
              <span>{isBackstoryLoading ? 'Incanting...' : 'Generate Backstory'}</span>
            </button>
          </div>

          {/* Backstory Text (1-2 sentences) */}
          <div className="relative min-h-[46px] flex items-center">
            <p 
              id="character-backstory-text"
              className="text-xs sm:text-[13px] text-amber-100/90 leading-relaxed font-serif italic selection:bg-amber-800"
            >
              "{character.backstory}"
            </p>
          </div>
        </div>

        {/* Task 5: Action Bar & "Save to Deck" Button */}
        <div className="pt-1 flex items-center gap-3">
          <button
            id="btn-save-to-deck"
            type="button"
            onClick={onSaveToDeck}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-cinzel font-bold text-sm transition-all duration-200 active:scale-98 cursor-pointer shadow-lg ${
              isSaved
                ? 'bg-gradient-to-r from-emerald-800 to-teal-900 border border-emerald-500/60 text-emerald-200 hover:bg-emerald-800/90'
                : 'bg-gradient-to-r from-amber-700 via-amber-600 to-amber-700 hover:from-amber-600 hover:to-amber-500 border border-amber-400/50 text-amber-950 font-extrabold shadow-amber-900/30'
            }`}
          >
            {isSaved ? (
              <>
                <BookmarkCheck className="w-4 h-4 text-emerald-300" />
                <span>Saved in Deck</span>
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4 text-amber-950 fill-amber-950/20" />
                <span>Save to Deck</span>
              </>
            )}
          </button>
        </div>

      </div>
    </motion.div>
  );
};
