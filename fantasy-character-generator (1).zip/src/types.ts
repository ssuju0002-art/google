export type CharacterClass =
  | 'Mage'
  | 'Rogue'
  | 'Warrior'
  | 'Paladin'
  | 'Necromancer'
  | 'Ranger'
  | 'Alchemist'
  | 'Druid'
  | 'Bard'
  | 'Warlock'
  | 'Cleric'
  | 'Barbarian';

export type CharacterRarity = 'Common' | 'Rare' | 'Epic' | 'Legendary';

export interface CharacterStats {
  health: number;
  mana: number;
  strength: number;
}

export interface Character {
  id: string;
  name: string;
  title: string;
  class: CharacterClass;
  stats: CharacterStats;
  portraitUrl: string;
  portraitStyle?: string;
  backstory: string;
  element: string;
  rarity: CharacterRarity;
  createdAt: number;
}

export interface DeckItem extends Character {
  savedAt: number;
}
