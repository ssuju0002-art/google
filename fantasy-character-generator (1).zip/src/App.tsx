import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Layers, 
  Download, 
  Dices, 
  Flame, 
  ShieldCheck, 
  Wand2, 
  Scroll, 
  BookOpen,
  Info
} from 'lucide-react';
import { Character, DeckItem } from './types';
import { 
  generateRandomCharacter, 
  generateCartoonPortraitSvg, 
  generateBackstoryOffline 
} from './utils/characterGenerator';
import { downloadSourceZip } from './utils/zipExporter';
import { PlayerCard } from './components/PlayerCard';
import { MyDeckModal } from './components/MyDeckModal';
import { WorkbenchDecorations } from './components/WorkbenchDecorations';

const DECK_STORAGE_KEY = 'fantasy_character_deck_v1';

export default function App() {
  // Current character on the workbench
  const [character, setCharacter] = useState<Character>(() => generateRandomCharacter());
  
  // Saved deck
  const [deck, setDeck] = useState<DeckItem[]>(() => {
    try {
      const saved = localStorage.getItem(DECK_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // State flags
  const [isDeckModalOpen, setIsDeckModalOpen] = useState(false);
  const [isPortraitLoading, setIsPortraitLoading] = useState(false);
  const [isBackstoryLoading, setIsBackstoryLoading] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [transmuteGlow, setTransmuteGlow] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Synchronize deck to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(DECK_STORAGE_KEY, JSON.stringify(deck));
    } catch (e) {
      console.error('Failed to persist deck to storage:', e);
    }
  }, [deck]);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((curr) => (curr === msg ? null : curr));
    }, 3200);
  };

  // Task 1: Generate a random fantasy character with unique Name and Class
  const handleGenerateRandomCharacter = () => {
    setTransmuteGlow(true);
    setTimeout(() => setTransmuteGlow(false), 600);
    const newChar = generateRandomCharacter();
    setCharacter(newChar);
    showToast(`Transmuted ${newChar.name}, the ${newChar.class}!`);
  };

  // Task 2: Generate Portrait
  const handleGeneratePortrait = async () => {
    setIsPortraitLoading(true);
    try {
      // Try AI endpoint first
      const res = await fetch('/api/generate-portrait', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: character.name,
          characterClass: character.class,
          style: 'cartoon video game',
        }),
      });

      const data = await res.json();
      if (data.imageUrl) {
        setCharacter((prev) => ({
          ...prev,
          portraitUrl: data.imageUrl,
          portraitStyle: 'AI Cartoon Video Game',
        }));
        showToast('AI character portrait summoned!');
      } else {
        // High-detail procedural video-game cartoon avatar
        const newSeed = Math.floor(Math.random() * 100000);
        const newSvg = generateCartoonPortraitSvg(character.name, character.class, newSeed);
        setCharacter((prev) => ({
          ...prev,
          portraitUrl: newSvg,
          portraitStyle: 'Stylized Cartoon RPG',
        }));
        showToast('Stylized RPG portrait generated!');
      }
    } catch (err) {
      console.warn('Fallback to vector avatar:', err);
      const newSeed = Math.floor(Math.random() * 100000);
      const newSvg = generateCartoonPortraitSvg(character.name, character.class, newSeed);
      setCharacter((prev) => ({
        ...prev,
        portraitUrl: newSvg,
      }));
      showToast('Portrait regenerated!');
    } finally {
      setIsPortraitLoading(false);
    }
  };

  // Task 2: Regenerate Portrait variation
  const handleRegeneratePortrait = async () => {
    setIsPortraitLoading(true);
    try {
      // Create fresh variation
      const freshSeed = Math.floor(Math.random() * 999999);
      const newSvg = generateCartoonPortraitSvg(character.name, character.class, freshSeed);
      setCharacter((prev) => ({
        ...prev,
        portraitUrl: newSvg,
        portraitStyle: 'Stylized Cartoon RPG (Regenerated)',
      }));
      showToast('Portrait varied and refreshed!');
    } finally {
      setIsPortraitLoading(false);
    }
  };

  // Task 4: Generate Backstory (1-2 sentence unique origin story)
  const handleGenerateBackstory = async () => {
    setIsBackstoryLoading(true);
    try {
      const res = await fetch('/api/generate-backstory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: character.name,
          characterClass: character.class,
          stats: character.stats,
        }),
      });

      const data = await res.json();
      if (data.backstory) {
        setCharacter((prev) => ({
          ...prev,
          backstory: data.backstory,
        }));
        showToast('New origin backstory chronicled by the oracle!');
      } else {
        // Fallback procedural generator
        const offlineLore = generateBackstoryOffline(character.name, character.class);
        setCharacter((prev) => ({
          ...prev,
          backstory: offlineLore,
        }));
        showToast('Ancient lore inscribed from the archives!');
      }
    } catch (err) {
      console.warn('Fallback backstory generator:', err);
      const offlineLore = generateBackstoryOffline(character.name, character.class);
      setCharacter((prev) => ({
        ...prev,
        backstory: offlineLore,
      }));
      showToast('Backstory refreshed!');
    } finally {
      setIsBackstoryLoading(false);
    }
  };

  // Task 5: Save to Deck
  const isSavedInDeck = deck.some((d) => d.id === character.id);

  const handleSaveToDeck = () => {
    if (isSavedInDeck) {
      // Remove from deck
      setDeck((prev) => prev.filter((d) => d.id !== character.id));
      showToast(`Removed ${character.name} from My Deck`);
    } else {
      // Add to deck
      const newDeckItem: DeckItem = {
        ...character,
        savedAt: Date.now(),
      };
      setDeck((prev) => [newDeckItem, ...prev]);
      showToast(`Added ${character.name} to My Deck!`);
    }
  };

  const handleRemoveFromDeck = (id: string) => {
    setDeck((prev) => prev.filter((d) => d.id !== id));
    showToast('Character removed from deck');
  };

  const handleClearDeck = () => {
    setDeck([]);
    showToast('Vault cleared');
  };

  // Task 6: Download Source Code as a ZIP file
  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    try {
      showToast('Compiling source code into ZIP...');
      await downloadSourceZip();
      showToast('Fantasy-Character-Generator.zip downloaded!');
    } catch (err) {
      console.error('ZIP download error:', err);
      showToast('Failed to download ZIP. Please try again.');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full alchemist-texture text-amber-100 flex flex-col justify-between overflow-x-hidden">
      {/* Ancient Alchemist Workbench background textures and animated runes */}
      <WorkbenchDecorations />

      {/* Atmospheric Top Navigation Header */}
      <header className="relative z-10 w-full border-b border-amber-900/40 bg-[#120e0b]/85 backdrop-blur-md px-4 py-3 sm:px-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          
          {/* Logo & Application Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-700 to-amber-950 border border-amber-500/50 flex items-center justify-center text-amber-300 shadow-md shadow-amber-950/50">
              <span className="text-xl">⚗</span>
            </div>
            <div>
              {/* Task 6: Exact name Fantasy Character Generator */}
              <h1 className="font-fantasy text-lg sm:text-xl text-amber-200 tracking-wide flex items-center gap-2">
                <span>Fantasy Character Generator</span>
              </h1>
              <p className="text-[11px] text-amber-500/80 font-cinzel tracking-wider uppercase hidden sm:block">
                Ancient Alchemist's Workbench • Card Vault
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2.5">
            {/* Task 5: My Deck Button with badge count */}
            <button
              id="btn-open-my-deck"
              type="button"
              onClick={() => setIsDeckModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-amber-950/70 hover:bg-amber-900/80 border border-amber-600/40 text-amber-200 font-cinzel text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-xs"
              title="View your saved character deck"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>My Deck</span>
              <span className="px-1.5 py-0.2 bg-amber-500 text-stone-950 rounded-full text-[11px] font-bold">
                {deck.length}
              </span>
            </button>

            {/* Task 6: Download Source ZIP Button */}
            <button
              id="btn-download-source-zip"
              type="button"
              onClick={handleDownloadZip}
              disabled={isDownloadingZip}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-900/90 hover:bg-stone-800 border border-amber-700/40 text-amber-300 font-cinzel text-xs font-semibold transition-all active:scale-95 disabled:opacity-50 cursor-pointer shadow-xs"
              title="Download the complete application source code as a ZIP file"
            >
              <Download className={`w-3.5 h-3.5 text-amber-400 ${isDownloadingZip ? 'animate-bounce' : ''}`} />
              <span className="hidden md:inline">Download ZIP</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workbench Area */}
      <main className="relative z-10 flex-1 max-w-6xl w-full mx-auto px-4 py-6 sm:py-8 flex flex-col items-center justify-center gap-6">
        
        {/* Task 1 Primary Button: Generate / Transmute Character */}
        <div className="flex flex-col items-center gap-2 text-center">
          <button
            id="btn-generate-character"
            type="button"
            onClick={handleGenerateRandomCharacter}
            className={`group relative flex items-center gap-3 px-8 py-3.5 rounded-2xl font-cinzel font-bold text-base sm:text-lg tracking-wider text-amber-100 bg-gradient-to-r from-amber-700 via-amber-600 to-amber-800 hover:from-amber-600 hover:via-amber-500 hover:to-amber-700 border-2 border-amber-400/60 shadow-[0_0_25px_rgba(217,119,6,0.35)] hover:shadow-[0_0_35px_rgba(245,158,11,0.5)] transition-all duration-300 active:scale-95 cursor-pointer ${
              transmuteGlow ? 'ring-4 ring-amber-400 scale-102' : ''
            }`}
          >
            <Dices className="w-5 h-5 sm:w-6 sm:h-6 text-amber-200 group-hover:rotate-180 transition-transform duration-500" />
            <span className="drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              Generate Fantasy Character
            </span>
            <Sparkles className="w-4 h-4 text-amber-200 animate-pulse" />
          </button>
          <p className="text-xs text-amber-400/70 font-cinzel tracking-wide">
            Click to transmute a unique Name, Class, and Combat Attributes
          </p>
        </div>

        {/* Task 5: Bordered Player Card containing:
            - Stylized fantasy font name (Task 3)
            - Class & unique traits (Task 1)
            - Cartoon portrait with Generate & Regenerate buttons (Task 2)
            - Health, Mana, and Strength randomized stats (Task 5)
            - 1-2 sentence origin backstory with Generate Backstory button (Task 4)
            - "Save to Deck" feature (Task 5)
        */}
        <div className="w-full flex justify-center">
          <PlayerCard
            character={character}
            isSaved={isSavedInDeck}
            onSaveToDeck={handleSaveToDeck}
            onGeneratePortrait={handleGeneratePortrait}
            onRegeneratePortrait={handleRegeneratePortrait}
            onGenerateBackstory={handleGenerateBackstory}
            isPortraitLoading={isPortraitLoading}
            isBackstoryLoading={isBackstoryLoading}
          />
        </div>

        {/* Workbench Lore / Tips Footnote */}
        <div className="flex items-center gap-2 text-xs text-amber-600/80 font-cinzel text-center max-w-md">
          <Sparkles className="w-3.5 h-3.5 shrink-0 text-amber-500" />
          <span>
            Every champion is uniquely forged with randomized stats, bespoke cartoon RPG artwork, and chronicled lore.
          </span>
        </div>
      </main>

      {/* Ancient Workbench Wooden Hearth Footer */}
      <footer className="relative z-10 w-full border-t border-amber-900/40 bg-[#0d0a08]/90 py-3.5 px-4 text-center">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-cinzel text-amber-500/70">
          <div className="flex items-center gap-2">
            <span>⚔ Fantasy Character Generator</span>
            <span>•</span>
            <span>Alchemical Codex</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setIsDeckModalOpen(true)}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Vault: {deck.length} Saved
            </button>
            <button
              type="button"
              onClick={handleDownloadZip}
              className="hover:text-amber-300 transition-colors cursor-pointer"
            >
              Export Project ZIP
            </button>
          </div>
        </div>
      </footer>

      {/* Notification Toast */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-950 to-stone-900 border border-amber-500/60 text-amber-100 text-xs font-cinzel font-semibold shadow-2xl shadow-black animate-in slide-in-from-bottom-3 duration-200 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
          <span>{notification}</span>
        </div>
      )}

      {/* Task 5: "My Deck" Modal */}
      <MyDeckModal
        isOpen={isDeckModalOpen}
        onClose={() => setIsDeckModalOpen(false)}
        deck={deck}
        onSelectCharacter={(char) => setCharacter(char)}
        onRemoveFromDeck={handleRemoveFromDeck}
        onClearDeck={handleClearDeck}
      />
    </div>
  );
}
