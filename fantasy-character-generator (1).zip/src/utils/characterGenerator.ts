import { Character, CharacterClass, CharacterRarity, CharacterStats } from '../types';

export const FANTASY_CLASSES: CharacterClass[] = [
  'Mage',
  'Rogue',
  'Warrior',
  'Paladin',
  'Necromancer',
  'Ranger',
  'Alchemist',
  'Druid',
  'Bard',
  'Warlock',
  'Cleric',
  'Barbarian',
];

const FIRST_NAMES = [
  'Aeloria', 'Valerius', 'Kaelen', 'Morrigan', 'Theron', 'Lyanna', 'Zephyrion',
  'Ignis', 'Seraphina', 'Vane', 'Baelor', 'Elidyr', 'Sylas', 'Rowan',
  'Darius', 'Cassian', 'Faelan', 'Aurelia', 'Grimwald', 'Nyx', 'Malakor',
  'Elowen', 'Corvus', 'Orion', 'Vespera', 'Branoc', 'Aldus', 'Isolde',
  'Thorin', 'Astrid', 'Garrick', 'Rhiannon', 'Draxos', 'Solas', 'Fenrir'
];

const SURNAMES = [
  'Shadowstride', 'Ironbreaker', 'Stormweaver', 'Sunspire', 'Nightbreeze',
  'Frostborne', 'Bloodthorn', 'Emberfang', 'Silverleaf', 'Voidwalker',
  'Dawnwhisper', 'Runechaser', 'Gravekeeper', 'Starcaller', 'Ashenheart',
  'Grimspire', 'Oakenheart', 'Duskbane', 'Crownbreaker', 'Wyrmseeker'
];

const TITLES = [
  'the Undaunted', 'the Spellweaver', 'of the Silent Order', 'the Flamekeeper',
  'of the Whispering Mist', 'the Relic Hunter', 'the Arcane Blade',
  'the Bone Binder', 'of the Gilded Aegis', 'the Shadow Stalker',
  'the Wandering Star', 'the Runesmith', 'of the Sunken Realm'
];

export const CLASS_THEMES: Record<CharacterClass, {
  color: string;
  badgeBg: string;
  badgeText: string;
  element: string;
  accentHex: string;
  borderHex: string;
  baseStats: { hp: [number, number]; mana: [number, number]; str: [number, number] };
  archetypeDesc: string;
}> = {
  Mage: {
    color: 'from-blue-600 to-indigo-900',
    badgeBg: 'bg-blue-950/80 border-blue-500/40',
    badgeText: 'text-blue-300',
    element: 'Arcane',
    accentHex: '#3b82f6',
    borderHex: '#60a5fa',
    baseStats: { hp: [60, 95], mana: [120, 190], str: [20, 50] },
    archetypeDesc: 'Master of arcane incantations and reality-bending spells.',
  },
  Rogue: {
    color: 'from-emerald-700 to-slate-900',
    badgeBg: 'bg-emerald-950/80 border-emerald-500/40',
    badgeText: 'text-emerald-300',
    element: 'Shadow',
    accentHex: '#10b981',
    borderHex: '#34d399',
    baseStats: { hp: [70, 110], mana: [50, 90], str: [65, 115] },
    archetypeDesc: 'Lethal operative operating unseen from the twilight shadows.',
  },
  Warrior: {
    color: 'from-red-700 to-stone-900',
    badgeBg: 'bg-red-950/80 border-red-500/40',
    badgeText: 'text-red-300',
    element: 'Physical',
    accentHex: '#ef4444',
    borderHex: '#f87171',
    baseStats: { hp: [110, 175], mana: [20, 50], str: [90, 150] },
    archetypeDesc: 'Battle-hardened vanguard clad in tempered steel.',
  },
  Paladin: {
    color: 'from-amber-600 to-yellow-950',
    badgeBg: 'bg-amber-950/80 border-amber-500/40',
    badgeText: 'text-amber-300',
    element: 'Radiance',
    accentHex: '#f59e0b',
    borderHex: '#fbbf24',
    baseStats: { hp: [100, 160], mana: [70, 120], str: [75, 130] },
    archetypeDesc: 'Holy champion wielding righteous light against darkness.',
  },
  Necromancer: {
    color: 'from-purple-800 to-black',
    badgeBg: 'bg-purple-950/80 border-purple-500/40',
    badgeText: 'text-purple-300',
    element: 'Decay',
    accentHex: '#a855f7',
    borderHex: '#c084fc',
    baseStats: { hp: [65, 100], mana: [110, 180], str: [30, 60] },
    archetypeDesc: 'Weaver of soul remnants and forbidden eternal covenants.',
  },
  Ranger: {
    color: 'from-green-700 to-teal-950',
    badgeBg: 'bg-green-950/80 border-green-500/40',
    badgeText: 'text-green-300',
    element: 'Nature',
    accentHex: '#22c55e',
    borderHex: '#4ade80',
    baseStats: { hp: [80, 120], mana: [50, 100], str: [70, 120] },
    archetypeDesc: 'Deadeye tracker bonded with untamed woodland beasts.',
  },
  Alchemist: {
    color: 'from-teal-700 to-stone-900',
    badgeBg: 'bg-teal-950/80 border-teal-500/40',
    badgeText: 'text-teal-300',
    element: 'Aether',
    accentHex: '#14b8a6',
    borderHex: '#2dd4bf',
    baseStats: { hp: [75, 115], mana: [90, 150], str: [45, 80] },
    archetypeDesc: 'Experimenter distilling volatile distillates and philosopher stones.',
  },
  Druid: {
    color: 'from-lime-700 to-stone-900',
    badgeBg: 'bg-lime-950/80 border-lime-500/40',
    badgeText: 'text-lime-300',
    element: 'Wild',
    accentHex: '#84cc16',
    borderHex: '#a3e635',
    baseStats: { hp: [85, 130], mana: [95, 145], str: [60, 105] },
    archetypeDesc: 'Shapeshifting guardian channeling ancient elder groves.',
  },
  Bard: {
    color: 'from-pink-700 to-purple-950',
    badgeBg: 'bg-pink-950/80 border-pink-500/40',
    badgeText: 'text-pink-300',
    element: 'Harmonics',
    accentHex: '#ec4899',
    borderHex: '#f472b6',
    baseStats: { hp: [70, 110], mana: [80, 135], str: [40, 85] },
    archetypeDesc: 'Charismatic minstrel whose ballads twist fate and inspire heroes.',
  },
  Warlock: {
    color: 'from-violet-900 to-red-950',
    badgeBg: 'bg-violet-950/80 border-violet-500/40',
    badgeText: 'text-violet-300',
    element: 'Abyssal',
    accentHex: '#8b5cf6',
    borderHex: '#a78bfa',
    baseStats: { hp: [75, 110], mana: [115, 175], str: [45, 80] },
    archetypeDesc: 'Contractor of otherworldly entities bound by eldritch pacts.',
  },
  Cleric: {
    color: 'from-cyan-700 to-slate-900',
    badgeBg: 'bg-cyan-950/80 border-cyan-500/40',
    badgeText: 'text-cyan-300',
    element: 'Grace',
    accentHex: '#06b6d4',
    borderHex: '#22d3ee',
    baseStats: { hp: [90, 140], mana: [100, 160], str: [55, 95] },
    archetypeDesc: 'Vessel of celestial deities offering restoration and judgment.',
  },
  Barbarian: {
    color: 'from-orange-800 to-amber-950',
    badgeBg: 'bg-orange-950/80 border-orange-500/40',
    badgeText: 'text-orange-300',
    element: 'Fury',
    accentHex: '#f97316',
    borderHex: '#fb923c',
    baseStats: { hp: [130, 200], mana: [10, 40], str: [110, 170] },
    archetypeDesc: 'Primal berserker empowered by furious ancestral spirits.',
  },
};

const RANDOM_ORIGIN_TEMPLATES = [
  "Born under a fractured blood moon, {NAME} survived a perilous exile in the forbidden spires. Now armed with ancient covenants, they seek retribution against the empire that cast them out.",
  "Found slumbering inside a shattered crystal monolith, {NAME} awakened with forgotten memories and innate mastery over {CLASS} arts. They wander the fractured realms seeking the true origin of their power.",
  "After accidentally breaking the seventh seal of their ancestral sanctuary, {NAME} was blessed and cursed in equal measure. Every battle they wage is a desperate struggle to keep their oath unbroken.",
  "Once a humble apprentice in the royal archives, {NAME} unearthed an encrypted grimoire and embraced the path of the {CLASS}. Their blade and spirit are now pledged only to the wanderer's code.",
  "Raised by renegade scholars in the subterranean catacombs, {NAME} mastered dangerous secrets before ever stepping into daylight. Whispers claim their true destiny was foretold in the ancient stars.",
  "Surviving a catastrophic alchemical catastrophe that claimed their entire guild, {NAME} emerged with heightened senses and relentless resolve. They now hunt the shadowy syndicate responsible for the catastrophe.",
  "Bound by a crimson pact sworn before the High Council, {NAME} walks the razor edge between salvation and ruin. No sanctuary will welcome them until their final quarry has fallen.",
  "Chosen by an elder spirit while stranded atop the howling Frostpeaks, {NAME} inherited powers that both terrify and inspire those around them. They tread into forgotten ruins where others fear to step."
];

export function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function generateRandomStats(characterClass: CharacterClass): CharacterStats {
  const theme = CLASS_THEMES[characterClass];
  return {
    health: getRandomInt(theme.baseStats.hp[0], theme.baseStats.hp[1]),
    mana: getRandomInt(theme.baseStats.mana[0], theme.baseStats.mana[1]),
    strength: getRandomInt(theme.baseStats.str[0], theme.baseStats.str[1]),
  };
}

export function generateBackstoryOffline(name: string, characterClass: CharacterClass): string {
  const template = RANDOM_ORIGIN_TEMPLATES[Math.floor(Math.random() * RANDOM_ORIGIN_TEMPLATES.length)];
  return template.replace(/{NAME}/g, name).replace(/{CLASS}/g, characterClass);
}

/**
 * Generates an intricately styled cartoon / video game portrait SVG as a data URI.
 * Crisp, vibrant, vector-based, featuring class-specific gear, armor, headwear, glowing eyes,
 * and magical backgrounds that look like modern indie RPG character cards.
 */
export function generateCartoonPortraitSvg(
  name: string,
  characterClass: CharacterClass,
  seed: number = Math.floor(Math.random() * 10000)
): string {
  const theme = CLASS_THEMES[characterClass];
  
  // Deterministic variants from seed
  const skinTones = ['#eec098', '#dca176', '#f2d3b4', '#8d5524', '#c68642', '#a67b5b', '#e0c8b0'];
  const skin = skinTones[seed % skinTones.length];
  
  const hairColors = ['#f59e0b', '#dc2626', '#3b82f6', '#10b981', '#ffffff', '#1e293b', '#9333ea', '#78350f'];
  const hairColor = hairColors[(seed >> 2) % hairColors.length];
  
  const eyeGlowColors = [theme.accentHex, '#38bdf8', '#fbbf24', '#a855f7', '#34d399', '#f43f5e'];
  const eyeGlow = eyeGlowColors[(seed >> 3) % eyeGlowColors.length];

  // Specific class gear accents
  let hatOrHeadgearSvg = '';
  let shoulderArmorSvg = '';
  let classIconSvg = '';
  let magicalAuraSvg = '';

  if (characterClass === 'Mage' || characterClass === 'Warlock' || characterClass === 'Necromancer') {
    hatOrHeadgearSvg = `
      <polygon points="100,20 60,85 140,85" fill="#1e1b4b" stroke="${theme.borderHex}" stroke-width="2.5" />
      <ellipse cx="100" cy="85" rx="46" ry="12" fill="#312e81" stroke="${theme.borderHex}" stroke-width="2" />
      <circle cx="100" cy="55" r="7" fill="${theme.accentHex}" />
    `;
    magicalAuraSvg = `
      <circle cx="100" cy="100" r="82" fill="none" stroke="${theme.accentHex}" stroke-width="1.5" stroke-dasharray="4,6" opacity="0.6" />
      <circle cx="45" cy="55" r="4" fill="${theme.accentHex}" filter="url(#blur)" />
      <circle cx="155" cy="65" r="5" fill="${theme.accentHex}" filter="url(#blur)" />
    `;
  } else if (characterClass === 'Rogue' || characterClass === 'Ranger') {
    hatOrHeadgearSvg = `
      <path d="M 60,95 C 60,40 140,40 140,95 C 135,110 65,110 60,95 Z" fill="#1e293b" stroke="${theme.borderHex}" stroke-width="2" />
      <path d="M 75,90 Q 100,105 125,90" stroke="#0f172a" stroke-width="4" fill="none" />
    `;
    magicalAuraSvg = `
      <path d="M 30,160 Q 60,120 40,80" stroke="${theme.accentHex}" stroke-width="2" fill="none" opacity="0.4" />
      <path d="M 170,160 Q 140,120 160,80" stroke="${theme.accentHex}" stroke-width="2" fill="none" opacity="0.4" />
    `;
  } else if (characterClass === 'Warrior' || characterClass === 'Paladin' || characterClass === 'Barbarian') {
    hatOrHeadgearSvg = `
      <path d="M 68,90 C 68,55 132,55 132,90 L 136,105 L 122,100 L 100,110 L 78,100 L 64,105 Z" fill="#334155" stroke="${theme.borderHex}" stroke-width="2.5" />
      <rect x="96" y="50" width="8" height="24" fill="${theme.accentHex}" rx="2" />
      <polygon points="100,32 94,48 106,48" fill="${theme.accentHex}" />
    `;
    shoulderArmorSvg = `
      <path d="M 30,160 L 55,130 L 75,145 L 45,185 Z" fill="#475569" stroke="${theme.borderHex}" stroke-width="2" />
      <path d="M 170,160 L 145,130 L 125,145 L 155,185 Z" fill="#475569" stroke="${theme.borderHex}" stroke-width="2" />
    `;
  } else {
    // Alchemist, Druid, Bard, Cleric
    hatOrHeadgearSvg = `
      <circle cx="100" cy="70" r="32" fill="${hairColor}" />
      <path d="M 65,75 Q 100,60 135,75" stroke="${theme.borderHex}" stroke-width="3" fill="none" />
      <circle cx="100" cy="62" r="6" fill="${theme.accentHex}" />
    `;
  }

  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
    <defs>
      <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#141013" />
        <stop offset="50%" stop-color="#241b18" />
        <stop offset="100%" stop-color="#0a0808" />
      </linearGradient>
      <linearGradient id="auraGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${theme.accentHex}" stop-opacity="0.5" />
        <stop offset="100%" stop-color="transparent" />
      </linearGradient>
      <filter id="glow">
        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
      <filter id="blur">
        <feGaussianBlur stdDeviation="2"/>
      </filter>
    </defs>

    <!-- Background -->
    <rect width="200" height="200" fill="url(#bgGrad)" />
    
    <!-- Ambient circle / halo -->
    <circle cx="100" cy="100" r="75" fill="url(#auraGrad)" />
    ${magicalAuraSvg}

    <!-- Body & Chest Armor / Robes -->
    <path d="M 50,200 L 65,145 L 135,145 L 150,200 Z" fill="#1c1917" stroke="${theme.borderHex}" stroke-width="2" />
    <path d="M 75,145 L 100,175 L 125,145 Z" fill="#292524" />
    <circle cx="100" cy="165" r="5" fill="${theme.accentHex}" filter="url(#glow)" />

    <!-- Shoulders -->
    ${shoulderArmorSvg}

    <!-- Neck -->
    <rect x="90" y="115" width="20" height="25" fill="${skin}" rx="3" />

    <!-- Face Base -->
    <ellipse cx="100" cy="98" rx="28" ry="32" fill="${skin}" stroke="#573824" stroke-width="1" />

    <!-- Ears -->
    <ellipse cx="71" cy="98" rx="4" ry="8" fill="${skin}" />
    <ellipse cx="129" cy="98" rx="4" ry="8" fill="${skin}" />

    <!-- Hair (Back/Sides) -->
    <path d="M 68,90 C 66,70 134,70 132,90 C 138,105 130,120 128,125 C 118,120 124,105 124,95 C 100,75 100,75 76,95 C 76,105 82,120 72,125 C 70,120 62,105 68,90 Z" fill="${hairColor}" />

    <!-- Eyes (Video game cartoon style) -->
    <ellipse cx="88" cy="95" rx="6" ry="8" fill="#0f172a" />
    <ellipse cx="112" cy="95" rx="6" ry="8" fill="#0f172a" />
    <circle cx="88" cy="94" r="3.5" fill="${eyeGlow}" filter="url(#glow)" />
    <circle cx="112" cy="94" r="3.5" fill="${eyeGlow}" filter="url(#glow)" />
    <circle cx="90" cy="92" r="1.5" fill="#ffffff" />
    <circle cx="114" cy="92" r="1.5" fill="#ffffff" />

    <!-- Eyebrows -->
    <path d="M 80,85 Q 88,82 96,87" stroke="#1c1917" stroke-width="2.5" stroke-linecap="round" fill="none" />
    <path d="M 120,85 Q 112,82 104,87" stroke="#1c1917" stroke-width="2.5" stroke-linecap="round" fill="none" />

    <!-- Nose -->
    <path d="M 100,95 L 98,104 L 102,104" stroke="#78350f" stroke-width="1.5" stroke-linecap="round" fill="none" opacity="0.6" />

    <!-- Mouth -->
    <path d="M 94,113 Q 100,117 106,113" stroke="#573824" stroke-width="2" stroke-linecap="round" fill="none" />

    <!-- Headgear / Hat -->
    ${hatOrHeadgearSvg}

    <!-- Frame Border -->
    <rect x="2" y="2" width="196" height="196" rx="10" fill="none" stroke="${theme.borderHex}" stroke-width="2" opacity="0.8" />
  </svg>
  `.trim();

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function generateRandomCharacter(): Character {
  const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const surname = SURNAMES[Math.floor(Math.random() * SURNAMES.length)];
  const title = TITLES[Math.floor(Math.random() * TITLES.length)];
  const characterClass = FANTASY_CLASSES[Math.floor(Math.random() * FANTASY_CLASSES.length)];
  const fullName = `${firstName} ${surname}`;
  
  const stats = generateRandomStats(characterClass);
  const backstory = generateBackstoryOffline(fullName, characterClass);
  const portraitUrl = generateCartoonPortraitSvg(fullName, characterClass);
  
  const rarities: CharacterRarity[] = ['Common', 'Rare', 'Epic', 'Legendary'];
  const rarityRoll = Math.random();
  const rarity: CharacterRarity = 
    rarityRoll > 0.85 ? 'Legendary' :
    rarityRoll > 0.60 ? 'Epic' :
    rarityRoll > 0.30 ? 'Rare' : 'Common';

  return {
    id: `char_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    name: fullName,
    title,
    class: characterClass,
    stats,
    portraitUrl,
    portraitStyle: 'Cartoon / Video Game',
    backstory,
    element: CLASS_THEMES[characterClass].element,
    rarity,
    createdAt: Date.now(),
  };
}
