import JSZip from 'jszip';

export async function downloadSourceZip(): Promise<void> {
  // First try the server endpoint
  try {
    const response = await fetch('/api/download-zip');
    if (response.ok) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Fantasy-Character-Generator.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      return;
    }
  } catch (err) {
    console.warn('Server zip route unavailable, generating client zip:', err);
  }

  // Fallback client-side generator
  const zip = new JSZip();

  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'fantasy-character-generator',
        private: true,
        version: '1.0.0',
        type: 'module',
        scripts: {
          dev: 'tsx server.ts',
          build: 'vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs',
          start: 'node dist/server.cjs',
          preview: 'vite preview',
        },
        dependencies: {
          '@google/genai': '^2.4.0',
          '@tailwindcss/vite': '^4.3.3',
          '@vitejs/plugin-react': '^6.1.1',
          dotenv: '^17.2.3',
          express: '^4.21.2',
          jszip: '^3.10.1',
          'lucide-react': '^0.546.0',
          motion: '^12.23.24',
          react: '^19.0.1',
          'react-dom': '^19.0.1',
          vite: '^8.3.0',
        },
      },
      null,
      2
    )
  );

  zip.file(
    'README.md',
    `# Fantasy Character Generator

Crafted on an ancient alchemist's workbench.

## Features
- Task 1: Random Fantasy Character Generator (Name, Class)
- Task 2: Character Portraits (Generate & Regenerate Cartoon / Video Game style portraits)
- Task 3: Ancient Alchemist Workbench UI with dark textured atmosphere and stylized fantasy typography
- Task 4: Character Backstory Generator (1-2 sentence unique origin story)
- Task 5: Bordered Player Card UI with randomized Health, Mana, and Strength stats & "Save to Deck" feature
- Task 6: Prototype named Fantasy Character Generator with 1-click source ZIP download

## Running locally:
\`\`\`bash
npm install
npm run dev
\`\`\`
`
  );

  const content = await zip.generateAsync({ type: 'blob' });
  const url = window.URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'Fantasy-Character-Generator.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}
